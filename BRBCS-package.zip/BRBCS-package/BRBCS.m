function [ ClassificationResult, ErrorRate] = BRBCS(TrainingData, TestData, C)
%% BRBCS: Belief rule based classification system
%   TrainingData: Training data (Num*Attribute(the first is class label))
%   TestData: Test data (Num*Attributes(the first is class label))
%   C: Number of fuzzy partitions per feature
%   ClassificationResult: Classification result (Num*1(Classification label))
%   ErrorRate: Classification error rate (wrongly classified Num / test Num)

%   Copyright 2012-2014 Lianmeng Jiao
%   $Version: 1.0 $  $Date: 2013/06/04 $
%   $Version: 2.0 $  $Date: 2014/06/04 $
%   $Version: 3.0 $  $Date: 2014/12/10 $ Revised the rule weight
%   calcualtion and revise the no-cover problem
%   $Version: 4.0 $  $Date: 2018/04/12 $ Revised the rule weight
%   calculation
DataSet = [TrainingData;TestData];
TrNum = size(TrainingData,1);
TeNum = size(TestData,1);
AtNum = size(TrainingData,2) - 1;
Error = 0;
R_Num = 1000;

% Partition the training data into subclass
for i = 1: TrNum
    Flag = 0;
    if i == 1
        Class{1} = {TrainingData(i,1), TrainingData(i,2:AtNum+1)};
    else
        for j = 1:size(Class,2)
            if TrainingData(i,1) == Class{j}{1}
                Class{j}{2} = [Class{j}{2};TrainingData(i,2:AtNum+1)];
                Flag = 1;
            end
        end
        if Flag == 0
            Class{size(Class,2)+1} = {TrainingData(i,1), TrainingData(i,2:AtNum+1)};
        end
    end
end

%% 1 BRB Generation
% 1-1 Establishment of the fuzzy regions
At_Max = max(DataSet(:,2:AtNum+1));
At_Min = min(DataSet(:,2:AtNum+1));
for i = 1:TrNum
    TrainingData(i,2:AtNum+1) = (TrainingData(i,2:AtNum+1) - At_Min)./(At_Max-At_Min);
end
for i = 1:TeNum
    TestData(i,2:AtNum+1) = (TestData(i,2:AtNum+1) - At_Min)./(At_Max-At_Min);
end

% 1-2 Generation of the antecedent part
Tem_Partition = [];
Tem_Consequence = [];
Tem_Matchdegree = [];
for i = 1:TrNum
    for m = 1:AtNum
        Partition(m) = 1;
        Membership(m) = MembershipFunc(TrainingData(i,m+1), C, 1);
        for c = 2:C
            if MembershipFunc(TrainingData(i,m+1), C, c) > Membership(m)
                Partition(m) = c;
                Membership(m) = MembershipFunc(TrainingData(i,m+1), C, c);
            end
        end
    end
    Tem_Partition = [Tem_Partition; Partition];
    Tem_Consequence = [Tem_Consequence; TrainingData(i,1)];
    Tem_Matchdegree = [Tem_Matchdegree; (prod(Membership))^(1/AtNum)];
end

[b1, m1, n1] = unique(Tem_Partition, 'rows');
R_Partition = b1;
Q = size(R_Partition,1);

for q = 1:Q
% 1-3 Generation of the consequent class
    I = find(n1 == q);
    K(q) = size(I,1);

    for c = 1:size(Class,2)
        c1 = 1;
        c2 = 1;
        c3 = 1;
        for k = 1:K(q)
            if Tem_Consequence(I(k)) == Class{c}{1}
                c1 = c1 * (1 - Tem_Matchdegree(I(k)));
            else
                c2 = c2 * (1 - Tem_Matchdegree(I(k)));
            end
        end
        m(q,c) = (1 - c1)*c2;
    end
    
    for k = 1:K(q)
        c3 = c3 * (1 - Tem_Matchdegree(I(k)));
    end
    m_Omega(q) = c3;
    Kd(q) = sum(m(q,:)) + m_Omega(q);
    m(q,:) = m(q,:)/Kd(q);
    m_Omega(q) = m_Omega(q)/Kd(q);
    
    R_Consequence(q,:) = m(q,:);
    
% 1-4 Generation of rule weight
%     R_Weight(q) = 1;
    % R_Weight(q) = K(q)/TrNum;
    R_Weight(q) = (sum(Tem_Matchdegree(I))/TrNum)^(1/3);
%     Conflict(q)=0;
%     if K(q) > 1
%         for i = 1:K(q)
%             for j = 1:K(q)
%                 if j > i
%                     if Tem_Consequence(I(j)) ~= Tem_Consequence(I(i))
%                         Conflict(q) = Conflict(q) + Tem_Matchdegree(I(i))*Tem_Matchdegree(I(j));
%                     end
%                 end
%             end
%         end
%         Conflict(q) = Conflict(q)/(K(q)*(K(q)-1));
%     end
%     Conf(q) = 1 - Conflict(q);
%     Sup(q) = (K(q)/TrNum)^(1/3);
%     R_Weight(q) =  Conf(q)*Sup(q);
end
% R_Weight = R_Weight/max(R_Weight);


% Find K rules with maximum weight
if size(R_Weight,2) > R_Num
    [ C1, I1 ] = KMax( R_Weight, R_Num);
    R_Weight = R_Weight(I1');
    R_Partition = R_Partition(I1,:);
    R_Consequence = R_Consequence(I1,:);
end
Q = size(R_Partition,1);

% 1-5 Generation of the feature weight
% for p = 1:AtNum
%     for k = 1:C
%         m_S(k,:) = zeros(1,size(Class,2));
%         m_Omega_S(k) = 0;
%         R_Weight_S(k) = 0;
%         for q = 1:Q
%             if R_Partition(q,p) == k
%                 m_S(k,:) = m_S(k,:) + R_Weight(q)*m(q,:);
%                 m_Omega_S(k) = m_Omega_S(k) + R_Weight(q)*m_Omega(q);
%                 R_Weight_S(k) = R_Weight_S(k) + R_Weight(q);
%             end
%         end
%         if R_Weight_S(k) == 0
%             m_Omega_S(k) = 1;
%         end
%     end
%     for k = 1:C-1
%         Delta_m(k,:) = m_S(k+1,:)-m_S(k,:);
%         Delta_m_Omega(k) = m_Omega_S(k+1) - m_Omega_S(k);
%         Delta_C(k) = sqrt(0.5 * (sum((Delta_m(k,:)).^2) + (Delta_m_Omega(k))^2) + (sum(Delta_m(k,:))*Delta_m_Omega(k))/size(Class,2)); 
%     end
%     CF(p) = sum(Delta_C(k))/(C-1);
% end
% delta = CF/max(CF);
delta = ones(1,AtNum);

%% 2 BRM 
for i = 1:TeNum
    Ind = [];
    for q = 1:Q
        Associationdegree(q) = R_Weight(q) * WeightedMatchDegree(TestData(i,2:AtNum+1),C,R_Partition(q,:),delta)^(1/AtNum);
        if Associationdegree(q) ~= 0
            Ind = [Ind q];
        end
    end
    L = size(Ind,2);
    if  L == 0 % If on rule is activated, the class is assigned as its nearest neighbor
        for m = 1:AtNum
            Partition_T(m) = 1;
            Membership_T(m) = MembershipFunc(TestData(i,m+1), C, 1);
            for c = 2:C
                if MembershipFunc(TestData(i,m+1), C, c) > Membership_T(m)
                    Partition_T(m) = c;
                    Membership_T(m) = MembershipFunc(TestData(i,m+1), C, c);
                end
            end
        end
        [C_p, I_p] = min(sum((ones(Q,1)*Partition_T-R_Partition).^2,2));
        CombinedBeliefDegree = R_Consequence(I_p,:);
    else 
        BliefMatrix = R_Consequence(Ind,:);
        Re_F = Associationdegree(Ind);
        Im_F = ones(1,L);
        [ CombinedBeliefDegree, RemainingBeliefDegree ] = EER( BliefMatrix,Re_F,Im_F);       
    end
    
     [C_c, I_c] = max(CombinedBeliefDegree);        
     ClassificationResult(i) = Class{I_c}{1};
     
     if  ClassificationResult(i) ~= TestData(i,1)
         Error = Error + 1;
     end
    
end

ErrorRate = Error / TeNum;
end
