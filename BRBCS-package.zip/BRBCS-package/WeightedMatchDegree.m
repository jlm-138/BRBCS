function [ matchdegree ] = WeightedMatchDegree(X,C,Partition,Delta)
%WeightedMatchDegree: Get the match degree of X considering featuer weight.
%   X: input vector
%   C: number of partitions
%   Partition: partition vector for all attributes
%   Delta: feature weight vector
%   matchdegree: the result membership

%   Copyright 2012-2014 Lianmeng Jiao
%   $Version: 1.0 $  $Date: 2013/06/04 $

matchdegree = 1;
for p = 1:size(X,2)
    matchdegree = matchdegree *  MembershipFunc(X(p), C, Partition(p))^Delta(p);
end

end

