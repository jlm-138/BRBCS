function [ CombinedBeliefDegree, RemainingBeliefDegree ] = EER( BliefMatrix,Re_F, Im_F)
%% EER -- extend evidential reasoning algorithm
%   BliefMatrix: the decision matrix [attributes'Num, evaluation grades'num]
%   Re_F: the reliability factor
%   CombinedBeliefDegree: the overall combined degree of belief(Hn)
%   RemainingBeliefDegree: the remaining belief degree unassigned to any decision (H)

%   Copyright 2012-2013 Lianmeng Jiao
%   $Revision: 1.0 $  $Date: 2012/09/25 $

[N, L] = size(BliefMatrix);

%% Step0: Compute the basic belief assignment (bba)
for i= 1:N
    bba(i,:) = BliefMatrix(i,:);
    bba_H(i) = 1 - sum(BliefMatrix(i,:));
end

%% Step1: Reliability-importance discounting
for i= 1:N
    ibba(i,:) = Re_F(i)*Im_F(i)*bba(i,:);
    ibba_H(i) = Re_F(i)*Im_F(i)*bba_H(i) + (1 - Re_F(i))*Im_F(i);
    ibba_Omega(i) = 1 - Im_F(i);
end

%% Step2: Aggregation process
% The initial value
m_ED(1,:) = ibba(1,:);
m_ED_H(1) = ibba_H(1);
m_ED_Omega(1) = ibba_Omega(1);
% The combined degree of belief by aggregating the first k attributes (m_ED)
for k = 1:N-1
    Temp = 0;
    for j = 1:L
        for p = 1:L
            if p ~= j
                Temp = Temp + m_ED(k,j)*ibba(k+1,p);
            end
        end
    end
    K(k+1) = 1/(1 - Temp);
    m_ED(k+1,:) = K(k+1) * (m_ED(k,:).*ibba(k+1,:) + (m_ED_H(k)+m_ED_Omega(k)).*ibba(k+1,:) + m_ED(k,:).*(ibba_H(k+1)+ibba_Omega(k+1)));
    m_ED_H(k+1) = K(k+1) * (m_ED_H(k)*ibba_H(k+1) + m_ED_H(k)*ibba_Omega(k+1) + m_ED_Omega(k)*ibba_H(k+1));
    m_ED_Omega(k+1) = K(k+1) * (m_ED_Omega(k)*ibba_Omega(k+1));
end

%% Step3: Belief degree normalization
CombinedBeliefDegree = m_ED(N,:) / (1 - m_ED_Omega(N));
RemainingBeliefDegree = m_ED_H(N) / (1 - m_ED_Omega(N));
% Sum = sum(CombinedBeliefDegree) + RemainingBeliefDegree
end

