function [ membership ] = MembershipFunc(x, C, i)
%MEMBERSHIPFUNC Get the membership of x.
%   x: input value
%   C: number of partitions
%   i: index of partition
%   membership: the result membership

%   Copyright 2012-2014 Lianmeng Jiao
%   $Version: 1.0 $  $Date: 2013/06/04 $

a = (i-1)/(C-1);
b = 1/(C-1);

tep = 1 - abs(x-a)/b;
membership = max([tep, 0]);

end

