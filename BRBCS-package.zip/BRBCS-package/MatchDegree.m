function [ matchdegree ] = MatchDegree(X,C,Partition)
%MatchDegree: Get the metch degree of X.
%   X: input vector
%   C: number of partitions
%   Partition: partition vector for all attributes
%   matchdegree: the result membership

%   Copyright 2012-2014 Lianmeng Jiao
%   $Version: 1.0 $  $Date: 2013/06/04 $

matchdegree = 1;
for p = 1:size(X,2)
    matchdegree = matchdegree *  MembershipFunc(X(p), C, Partition(p));
end

end

