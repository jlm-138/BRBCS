function [ C, I ] = KMax( input, k )
%% KMAX Find the K maximum values in input vector
%   input: input vector
%   k: the num of the maximum value
%   C: the value vector containing K maximum values in input vector
%   I: the index vector containing K maximum values in input vector

%   Copyright 2012-2014 Lianmeng Jiao
%   $Version: 1.0 $  $Date: 2013/06/04 $

C = zeros(1,k);
I = zeros(1,k);
for index = 1:k
    [c, i] = max(input);
    input(i) = -Inf;
    C(index) = c;
    I(index) = i;
end

end

